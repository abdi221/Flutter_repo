package com.example.todolist_a2

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
